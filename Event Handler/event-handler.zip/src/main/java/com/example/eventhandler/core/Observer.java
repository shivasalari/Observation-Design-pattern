package com.example.eventhandler.core;

public interface Observer {
	public void onEvent(Event event);
}
