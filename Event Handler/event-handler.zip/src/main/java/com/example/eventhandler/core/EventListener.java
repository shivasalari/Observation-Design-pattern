package com.example.eventhandler.core;


public interface EventListener extends Observer {
	
}
