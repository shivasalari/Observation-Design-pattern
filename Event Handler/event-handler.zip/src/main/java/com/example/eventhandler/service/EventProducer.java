package com.example.eventhandler.service;

public interface EventProducer {

	public void produceEvent();
	
}
